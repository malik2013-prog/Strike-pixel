# Strike Pixel API — ГОТОВО К ДЕПЛОЮ

Твои данные (уже прописаны в коде, но при деплое введи их в Environment Variables):

- **TELEGRAM_BOT_TOKEN**: `8526511994:AAEIU76j5fenVueuLFHUaTss2kFkPe5xVn4`
- **TELEGRAM_CHAT_ID**: `8315588207`

## 🚀 Деплой (2 минуты)

1. Иди на [vercel.com](https://vercel.com)
2. Sign Up (через GitHub быстрее всего)
3. Нажми **Add New... → Project**
4. Выбери **Upload** (перетащи папку `vercel-api-ready`)
5. После загрузки нажми **Deploy**
6. Перейди в проект → **Settings → Environment Variables**
7. Добавь:
   - `TELEGRAM_BOT_TOKEN` = `8526511994:AAEIU76j5fenVueuLFHUaTss2kFkPe5xVn4`
   - `TELEGRAM_CHAT_ID` = `8315588207`
8. Нажми **Redeploy** (или дождись автоматического)
9. Получишь URL: `https://ТВОЙ-ПРОЕКТ.vercel.app`
10. Запомни его — он понадобится для сайта!

## 🔗 Подключение к сайту

В `index.html` найди:
```javascript
const VERCEL_API_URL='https://strike-pixel-api.vercel.app/api/send';
```

Замени на свой URL:
```javascript
const VERCEL_API_URL='https://ТВОЙ-ПРОЕКТ.vercel.app/api/send';
```

Готово!
